# YOLO26 Object Detection Studio

A Streamlit product that wraps **Ultralytics YOLO26** for real-time object
detection: image upload, video upload, and live webcam — each with confidence
scores and error handling.

## 1. Setup

```bash
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

First run will auto-download the YOLO26 weights (a few MB to ~50MB depending
on model size) from Ultralytics' GitHub releases.

## 2. Run

```bash
streamlit run app.py
```

This opens the app at `http://localhost:8501`.

- **Image tab** — upload a `.jpg/.png/...`, see the annotated image + a table
  of detected classes and confidence scores.
- **Video tab** — upload a short `.mp4/.mov/...`, see an annotated preview
  video + an aggregated confidence summary per class.
- **Live Webcam tab** — real-time detection from your webcam via
  `streamlit-webrtc`. **This tab requires running the app on your own machine**
  (with a webcam) — it will not work in a headless/cloud sandbox with no camera.
- Adjust confidence/IoU thresholds and model size (Nano/Small/Medium) from the
  sidebar.

## 3. Error handling included

- Unsupported file type or oversized upload → clear message, no crash
- Corrupt/unreadable video → clear message
- Model fails to load (e.g. no internet for first download) → surfaced in the
  sidebar, all tabs disable inference gracefully
- Any unexpected inference exception → caught, shown to the user, with a
  "technical details" expander (not a stack trace dump on screen)

## 4. Recording the demo video (3–5 minutes)

Suggested script:

1. **(0:00–0:30)** Intro — what the app does, that it's powered by YOLO26.
2. **(0:30–1:30)** Image tab — upload a photo with multiple objects (people,
   cars, animals), show the annotated output and the confidence table. Adjust
   the confidence slider to show detections appearing/disappearing.
3. **(1:30–2:30)** Video tab — upload a short clip, show the annotated output
   video and the aggregated per-class confidence summary.
4. **(2:30–3:30)** Live Webcam tab — start the stream, show real-time
   detection on yourself/objects in the room.
5. **(3:30–4:30)** Error handling — upload an unsupported file (e.g. a `.txt`)
   to show the friendly error message; optionally show what happens with a
   very low-confidence threshold (many false positives) vs. a high one.
6. **(4:30–5:00)** Wrap-up — mention model options (Nano/Small/Medium) and
   close.

Use any screen recorder (OBS, QuickTime screen recording, Windows Game Bar,
Loom) capturing the browser window while `streamlit run app.py` is active.

## 5. Files

- `app.py` — the Streamlit application
- `requirements.txt` — dependencies
- `README.md` — this file
